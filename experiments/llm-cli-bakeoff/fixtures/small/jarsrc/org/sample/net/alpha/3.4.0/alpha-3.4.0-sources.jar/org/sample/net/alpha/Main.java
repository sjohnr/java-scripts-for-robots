package org.sample.net.alpha;

public class Main {
    public int method0(int x) {
        return x + 21;
    }
    public int method1(int x) {
        return x + 95;
    }
    public int method2(int x) {
        return x + 54;
    }
    public int method3(int x) {
        return x + 54;
    }
}
