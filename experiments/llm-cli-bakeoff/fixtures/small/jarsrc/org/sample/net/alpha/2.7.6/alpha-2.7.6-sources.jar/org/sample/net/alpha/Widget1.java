package org.sample.net.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 40;
    }
    public int method1(int x) {
        return x + 21;
    }
}
