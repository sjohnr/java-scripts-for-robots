package org.sample.net.alpha;

public class Widget3 {
    public int method0(int x) {
        return x + 18;
    }
    public int method1(int x) {
        return x + 77;
    }
}
