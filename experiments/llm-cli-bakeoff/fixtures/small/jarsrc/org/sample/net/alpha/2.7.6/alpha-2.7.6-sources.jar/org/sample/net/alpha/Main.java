package org.sample.net.alpha;

public class Main {
    public int method0(int x) {
        return x + 22;
    }
    public int method1(int x) {
        return x + 76;
    }
}
