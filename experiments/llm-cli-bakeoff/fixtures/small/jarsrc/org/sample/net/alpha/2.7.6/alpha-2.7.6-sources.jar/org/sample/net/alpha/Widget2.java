package org.sample.net.alpha;

public class Widget2 {
    public int method0(int x) {
        return x + 85;
    }
    public int method1(int x) {
        return x + 24;
    }
    public int method2(int x) {
        return x + 91;
    }
    public int method3(int x) {
        return x + 26;
    }
    public int method4(int x) {
        return x + 89;
    }
}
