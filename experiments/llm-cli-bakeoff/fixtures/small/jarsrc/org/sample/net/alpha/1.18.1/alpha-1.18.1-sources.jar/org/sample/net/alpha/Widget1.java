package org.sample.net.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 24;
    }
    public int method1(int x) {
        return x + 73;
    }
    public int method2(int x) {
        return x + 18;
    }
    public int method3(int x) {
        return x + 84;
    }
}
