package org.sample.net.alpha;

public class Widget4 {
    public int method0(int x) {
        return x + 9;
    }
    public int method1(int x) {
        return x + 33;
    }
    public int method2(int x) {
        return x + 69;
    }
}
