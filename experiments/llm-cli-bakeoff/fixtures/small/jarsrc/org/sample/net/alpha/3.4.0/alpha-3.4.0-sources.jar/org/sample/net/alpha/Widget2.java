package org.sample.net.alpha;

public class Widget2 {
    public int method0(int x) {
        return x + 83;
    }
    public int method1(int x) {
        return x + 22;
    }
    public int method2(int x) {
        return x + 90;
    }
    public int method3(int x) {
        return x + 52;
    }
    public int method4(int x) {
        return x + 84;
    }
}
