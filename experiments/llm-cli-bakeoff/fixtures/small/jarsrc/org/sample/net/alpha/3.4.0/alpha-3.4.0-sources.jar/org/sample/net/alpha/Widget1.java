package org.sample.net.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 91;
    }
    public int method1(int x) {
        return x + 70;
    }
    public int method2(int x) {
        return x + 79;
    }
    public int method3(int x) {
        return x + 28;
    }
}
