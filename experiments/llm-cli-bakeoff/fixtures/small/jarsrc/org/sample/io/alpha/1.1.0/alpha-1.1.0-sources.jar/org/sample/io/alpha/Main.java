package org.sample.io.alpha;

public class Main {
    public int method0(int x) {
        return x + 13;
    }
    public int method1(int x) {
        return x + 63;
    }
    public int method2(int x) {
        return x + 47;
    }
}
