package org.sample.io.alpha;

public class Widget4 {
    public int method0(int x) {
        return x + 92;
    }
    public int method1(int x) {
        return x + 70;
    }
}
