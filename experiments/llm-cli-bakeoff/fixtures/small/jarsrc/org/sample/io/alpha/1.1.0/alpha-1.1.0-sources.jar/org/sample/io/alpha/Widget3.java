package org.sample.io.alpha;

public class Widget3 {
    public int method0(int x) {
        return x + 20;
    }
    public int method1(int x) {
        return x + 77;
    }
    public int method2(int x) {
        return x + 52;
    }
    public int method3(int x) {
        return x + 99;
    }
}
