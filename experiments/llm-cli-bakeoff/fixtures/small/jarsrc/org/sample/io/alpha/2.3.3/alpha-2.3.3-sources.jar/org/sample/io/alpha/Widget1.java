package org.sample.io.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 37;
    }
    public int method1(int x) {
        return x + 58;
    }
    public int method2(int x) {
        return x + 70;
    }
    public int method3(int x) {
        return x + 57;
    }
}
