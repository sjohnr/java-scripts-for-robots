package org.sample.io.alpha;

public class Main {
    public int method0(int x) {
        return x + 97;
    }
    public int method1(int x) {
        return x + 42;
    }
}
