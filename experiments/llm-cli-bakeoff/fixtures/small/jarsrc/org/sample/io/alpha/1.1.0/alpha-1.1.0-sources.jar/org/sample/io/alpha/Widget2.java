package org.sample.io.alpha;

public class Widget2 {
    public int method0(int x) {
        return x + 66;
    }
    public int method1(int x) {
        return x + 74;
    }
}
