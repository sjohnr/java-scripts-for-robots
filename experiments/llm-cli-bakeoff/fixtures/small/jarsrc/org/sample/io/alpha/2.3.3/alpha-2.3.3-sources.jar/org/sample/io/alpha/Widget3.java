package org.sample.io.alpha;

public class Widget3 {
    public int method0(int x) {
        return x + 67;
    }
    public int method1(int x) {
        return x + 41;
    }
    public int method2(int x) {
        return x + 46;
    }
}
