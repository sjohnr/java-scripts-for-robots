package com.example.util.alpha;

public class Widget4 {
    public int method0(int x) {
        return x + 25;
    }
}
