package com.example.util.alpha;

public class Widget4 {
    public int method0(int x) {
        return x + 37;
    }
    public int method1(int x) {
        return x + 3;
    }
    public int method2(int x) {
        return x + 90;
    }
}
