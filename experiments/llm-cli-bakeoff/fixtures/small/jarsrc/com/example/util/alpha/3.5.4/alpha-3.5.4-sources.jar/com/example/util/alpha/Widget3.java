package com.example.util.alpha;

public class Widget3 {
    public int method0(int x) {
        return x + 36;
    }
    public int method1(int x) {
        return x + 15;
    }
    public int method2(int x) {
        return x + 65;
    }
}
