package com.example.util.alpha;

public class Widget2 {
    public int method0(int x) {
        return x + 78;
    }
    public int method1(int x) {
        return x + 5;
    }
    public int method2(int x) {
        return x + 85;
    }
    public int method3(int x) {
        return x + 52;
    }
    public int method4(int x) {
        return x + 73;
    }
}
