package com.example.util.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 1;
    }
}
