package com.example.util.alpha;

public class Widget3 {
    public int method0(int x) {
        return x + 49;
    }
}
