package com.example.util.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 21;
    }
    public int method1(int x) {
        return x + 87;
    }
    public int method2(int x) {
        return x + 22;
    }
}
