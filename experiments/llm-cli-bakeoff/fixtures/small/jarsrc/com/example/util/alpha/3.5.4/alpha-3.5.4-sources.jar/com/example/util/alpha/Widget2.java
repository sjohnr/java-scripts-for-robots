package com.example.util.alpha;

public class Widget2 {
    public int method0(int x) {
        return x + 57;
    }
    public int method1(int x) {
        return x + 88;
    }
}
