package com.example.util.alpha;

public class Main {
    public int method0(int x) {
        return x + 60;
    }
    public int method1(int x) {
        return x + 1;
    }
    public int method2(int x) {
        return x + 59;
    }
}
