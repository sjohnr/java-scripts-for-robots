package com.example.core.alpha;

public class Widget5 {
    public int method0(int x) {
        return x + 76;
    }
}
