package com.example.core.alpha;

public class Widget3 {
    public int method0(int x) {
        return x + 46;
    }
}
