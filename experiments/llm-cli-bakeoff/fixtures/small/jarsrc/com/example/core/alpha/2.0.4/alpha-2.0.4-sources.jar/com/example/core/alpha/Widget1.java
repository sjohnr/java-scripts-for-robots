package com.example.core.alpha;

public class Widget1 {
    public int method0(int x) {
        return x + 38;
    }
    public int method1(int x) {
        return x + 8;
    }
    public int method2(int x) {
        return x + 5;
    }
}
