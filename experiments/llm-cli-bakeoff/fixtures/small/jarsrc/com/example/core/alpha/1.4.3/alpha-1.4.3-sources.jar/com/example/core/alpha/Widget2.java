package com.example.core.alpha;

public class Widget2 {
    public int method0(int x) {
        return x + 91;
    }
    public int method1(int x) {
        return x + 10;
    }
    public int method2(int x) {
        return x + 31;
    }
    public int method3(int x) {
        return x + 96;
    }
    public int method4(int x) {
        return x + 95;
    }
}
