package com.example.core.alpha;

public class Main {
    public int method0(int x) {
        return x + 46;
    }
    public int method1(int x) {
        return x + 34;
    }
    public int method2(int x) {
        return x + 32;
    }
}
