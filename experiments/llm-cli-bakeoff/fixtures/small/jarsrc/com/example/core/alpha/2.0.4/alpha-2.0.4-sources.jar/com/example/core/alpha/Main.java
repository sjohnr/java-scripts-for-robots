package com.example.core.alpha;

public class Main {
    public int method0(int x) {
        return x + 49;
    }
}
